#include "usart.h"

//Servo
uint8_t UART_RX_BUF[16];
bool isUartRxCompleted = false;

//USART2
static unsigned char TxBuffer[256];
static unsigned char TxCounter = 0;
static unsigned char count = 0;
extern void CopeSerial6Data(unsigned char ucData);

//Bluetooth
uint8_t USART3_RX_BUF[USART_REC_LEN];

//����״̬
//bit15��	������ɱ�־
//bit14��	���յ�0x0d
//bit13~0��	���յ�����Ч�ֽ���Ŀ
uint16_t USART3_RX_STA = 0;

/*----------------------------------------------*
 *            USART1, �������
 *----------------------------------------------*/
int fputc(int ch, FILE* f)
{
    if(ch == '\n')
    {
        USART_SendData(USART1, 0x0D);
        while(!(USART1->SR & USART_FLAG_TXE));
        USART_SendData(USART1, 0x0A);
        while(!(USART1->SR & USART_FLAG_TXE));
    }
    else
    {
        USART_SendData(USART1, (unsigned char)ch);
        while(!(USART1->SR & USART_FLAG_TXE));
    }
    return ch;
}

void uartNVICInit(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void uart1_init(uint32_t bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

    GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_USART1);
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource7, GPIO_AF_USART1);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    USART_InitStructure.USART_BaudRate = bound;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    USART_Init(USART1, &USART_InitStructure);
    uartNVICInit();
    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART1, ENABLE);
}

void uartWriteBuf(uint8_t* buf, uint8_t len)
{
    while(len--)
    {
        while((USART1->SR & 0x40) == 0);
        USART_SendData(USART1, *buf++);
    }
}

extern uint8_t LobotRxBuf[16];

void USART1_IRQHandler(void)
{
    uint8_t Res;
    static bool isGotFrameHeader = false;
    static uint8_t frameHeaderCount = 0;
    static uint8_t dataLength = 2;
    static uint8_t dataCount = 0;
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        Res = USART_ReceiveData(USART1);
        if(!isGotFrameHeader)
        {
            if(Res == FRAME_HEADER)
            {
                frameHeaderCount++;
                if(frameHeaderCount == 2)
                {
                    frameHeaderCount = 0;
                    isGotFrameHeader = true;
                    dataCount = 1;
                }
            }
            else
            {
                isGotFrameHeader = false;
                dataCount = 0;
                frameHeaderCount = 0;
            }
        }
        if(isGotFrameHeader)
        {
            UART_RX_BUF[dataCount] = Res;
            if(dataCount == 2)
            {
                dataLength = UART_RX_BUF[dataCount];
                if(dataLength < 2 || dataLength > 8)
                {
                    dataLength = 2;
                    isGotFrameHeader = false;
                }
            }
            dataCount++;
            if(dataCount == dataLength + 2)
            {
                if(isUartRxCompleted == false)
                {
                    isUartRxCompleted = true;
                    memcpy(LobotRxBuf, UART_RX_BUF, dataCount);
                }
                isGotFrameHeader = false;
            }
        }
    }
}

/*----------------------------------------------*
 *              USART2,JY901������
 *----------------------------------------------*/
void uart2_init(uint32_t bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

    GPIO_PinAFConfig(GPIOD, GPIO_PinSource5, GPIO_AF_USART2);
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource6, GPIO_AF_USART2);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5 | GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1 ; //��ռ���ȼ�
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;		//�����ȼ�
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
    NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���

    //UART ��ʼ������
    USART_InitStructure.USART_BaudRate = bound;//���ڲ�����
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;//�ֳ�Ϊ8λ���ݸ�ʽ
    USART_InitStructure.USART_StopBits = USART_StopBits_1;//һ��ֹͣλ
    USART_InitStructure.USART_Parity = USART_Parity_No;//����żУ��λ
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//��Ӳ������������
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;	//�շ�ģʽ

    USART_Init(USART2, &USART_InitStructure);
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    USART_Cmd(USART2, ENABLE);
}

void USART2_IRQHandler(void)
{
    if(USART_GetITStatus(USART2, USART_IT_TXE) != RESET)
    {
        USART_SendData(USART2, TxBuffer[TxCounter++]);
        USART_ClearITPendingBit(USART2, USART_IT_TXE);
        if(TxCounter == count) USART_ITConfig(USART2, USART_IT_TXE, DISABLE);
    }
    else if(USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        CopeSerial6Data((unsigned char)USART2->DR);//��������
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
    USART_ClearITPendingBit(USART2, USART_IT_ORE);
}

void UART2_Put_Char(unsigned char DataToSend)
{
    TxBuffer[count++] = DataToSend;
    USART_ITConfig(USART2, USART_IT_TXE, ENABLE);
}

/*----------------------------------------------*
 *              USART3, Bluetooth
 *----------------------------------------------*/
void uart3_init(uint32_t bound)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    USART_InitTypeDef USART_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE); //ʹ��USART3ʱ��
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE); //ʹ��GPIOBʱ��
    
    //����3��Ӧ���Ÿ���ӳ��
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3); //GPIOB10����ΪUSART3 TX
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3); //GPIOB11����ΪUSART3 RX

    //USART3�˿�����
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11; //GPIOB10��GPIOB11
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;//���ù���
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	//�ٶ�50MHz
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //���츴�����
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP; //����
    GPIO_Init(GPIOB, &GPIO_InitStructure); //��ʼ��PB10��PB11

    //USART ��ʼ������
    USART_InitStructure.USART_BaudRate = bound;//���ڲ�����
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;//�ֳ�Ϊ8λ���ݸ�ʽ
    USART_InitStructure.USART_StopBits = USART_StopBits_1;//һ��ֹͣλ
    USART_InitStructure.USART_Parity = USART_Parity_No;//����żУ��λ
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;//��Ӳ������������
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;	//�շ�ģʽ

    USART_Cmd(USART3, ENABLE);                    //ʹ�ܴ���3
	USART_Init(USART3, &USART_InitStructure); //��ʼ������3
	USART_ClearFlag(USART3, USART_FLAG_TC);
    USART_ITConfig(USART3, USART_IT_RXNE, ENABLE);//�������ڽ����ж�
    
	NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; //��ռ���ȼ�
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;		//�����ȼ�
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;			//IRQͨ��ʹ��
    NVIC_Init(&NVIC_InitStructure);	//����ָ���Ĳ�����ʼ��VIC�Ĵ���
}

void USART3_IRQHandler(void)      //����3�жϷ������
{
	uint8_t Res;
	if(USART_GetITStatus(USART3, USART_IT_RXNE) != RESET)  //�����ж�(���յ������ݱ�����0x0d 0x0a��β)
	{
		Res =USART_ReceiveData(USART3);	//��ȡ���յ�������
		if((USART3_RX_STA&0x8000)==0)//����δ���
		{
			if(USART3_RX_STA&0x4000)
			{
			    if(Res==0xFF)
				{
					USART3_RX_STA|=0x8000;
				}
				else
				{
					USART3_RX_BUF[USART3_RX_STA&0X3FFF]=Res ;
					USART3_RX_STA++;
				}
			}
			else if(Res==0xAA)
			{
				USART3_RX_STA|=0x4000;
			}
		}
     }
}

void uart3WriteBuf(uint8_t* buf, uint8_t len)
{
    while(len--)
    {
        while((USART3->SR & 0x40) == 0);
        USART_SendData(USART3, *buf++);
    }
}
