#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "stm32f4xx_conf.h"
#include "sys.h" 

#define USART_REC_LEN  			200  	//�����������ֽ��� 200

extern uint8_t UART_RX_BUF[];

extern uint8_t USART3_RX_BUF[];
extern uint16_t USART3_RX_STA;

//Servo
void uart1_init(uint32_t bound);
void uartWriteBuf(uint8_t *buf, uint8_t len);
//JY901
void uart2_init(uint32_t bound);
void UART2_Put_Char(unsigned char DataToSend);
//Bluetooth
void uart3_init(uint32_t bound);
void uart3WriteBuf(uint8_t *buf, uint8_t len);

#endif


