#include "motor.h"

void motor_gpio_init(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

void Motor_1_STOP(void)
{
	IN1(Low);
	IN2(Low);
}
 
void Motor_1_PRun(void)
{
	IN1(High);
	IN2(Low);
}
 
void Motor_1_NRun(void)
{
	IN1(Low);
	IN2(High);
}
 
void Motor_2_STOP(void)
{
	IN3(Low);
	IN4(Low);
}
 
void Motor_2_NRun(void)             
{
	IN4(High);
	IN3(Low);
}
 
void Motor_2_PRun(void)
{
	
	IN4(Low);
	IN3(High);
}

void Motor_3_STOP(void)
{
	IN5(Low);
	IN6(Low);
}
 
void Motor_3_PRun(void)
{
	IN6(High);
	IN5(Low);
}
 
void Motor_3_NRun(void)
{
	
	IN6(Low);
	IN5(High);
}
void Motor_4_STOP(void)
{
	IN7(Low);
	IN8(Low);
}
 
void Motor_4_PRun(void)
{
	IN8(High);
	IN7(Low);
}
 
void Motor_4_NRun(void)
{
	IN8(Low);
	IN7(High);
}

void Motor_Backward(void)
{
	Motor_1_PRun();
	Motor_2_PRun();
	Motor_3_PRun();
	Motor_4_PRun();
}
void Motor_Forward(void)
{
	Motor_1_NRun();
	Motor_2_NRun();
	Motor_3_NRun();
	Motor_4_NRun();
}
void Motor_Right(void)
{
	Motor_1_NRun();
	Motor_2_PRun();
	Motor_3_NRun();
	Motor_4_PRun();
}
void Motor_Left(void)
{
	Motor_1_PRun();
	Motor_2_NRun();
	Motor_3_PRun();
	Motor_4_NRun();
}

void Motor_Stop(void)
{
	Motor_1_STOP();
	Motor_2_STOP();
	Motor_3_STOP();
	Motor_4_STOP();
}

void Motor_TopRight(void)
{
	Motor_1_NRun();
	Motor_2_STOP();
	Motor_3_NRun();
	Motor_4_STOP();
}

void Motor_TopLeft(void)
{
	Motor_1_STOP();
	Motor_2_NRun();
	Motor_3_STOP();
	Motor_4_NRun();
}

void Motor_DownRight(void)
{
	Motor_1_STOP();
	Motor_2_NRun();
	Motor_3_STOP();
	Motor_4_NRun();
}

void Motor_DownLeft(void)
{
	Motor_1_PRun();
	Motor_2_STOP();
	Motor_3_PRun();
	Motor_4_STOP();
}

void Motor_Nspin(void)
{
	Motor_1_PRun();
	Motor_2_PRun();
	Motor_3_NRun();
	Motor_4_NRun();
}

void Motor_Sspin(void)
{
	Motor_1_NRun();
	Motor_2_NRun();
	Motor_3_PRun();
	Motor_4_PRun();
}
