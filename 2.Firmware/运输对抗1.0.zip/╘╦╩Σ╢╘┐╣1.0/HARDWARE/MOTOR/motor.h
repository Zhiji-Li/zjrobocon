#ifndef __MOTOR_H__
#define __MOTOR_H__
#include "sys.h"

#define High    1
#define Low     0

#define IN1(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_2);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_2)
 
#define IN2(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_3);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_3)
 
#define IN3(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_4);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_4)
 
#define IN4(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_5);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_5)

#define IN5(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_12);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_12)

#define IN6(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_13);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_13)

#define IN7(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_14);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_14)

#define IN8(a) if (a)  \
	GPIO_SetBits(GPIOB,GPIO_Pin_15);\
else  \
	GPIO_ResetBits(GPIOB,GPIO_Pin_15)


void motor_gpio_init(void);

void Motor_1_STOP(void);
void Motor_1_PRun(void);
void Motor_1_NRun(void);
 
void Motor_2_STOP(void);
void Motor_2_PRun(void);
void Motor_2_NRun(void);

void Motor_3_STOP(void);
void Motor_3_PRun(void);
void Motor_3_NRun(void);

void Motor_4_STOP(void);
void Motor_4_PRun(void);
void Motor_4_NRun(void);

void Motor_Forward(void);
void Motor_Backward(void);
void Motor_Left(void);
void Motor_Right(void);
void Motor_Stop(void);
void Motor_TopRight(void);
void Motor_TopLeft(void);
void Motor_DownRight(void);
void Motor_DownLeft(void);
void Motor_Sspin(void);
void Motor_Nspin(void);

#endif
