#ifndef __ADC_H__
#define __ADC_H__
#include "sys.h"

void Adc_Init(void);

#endif
