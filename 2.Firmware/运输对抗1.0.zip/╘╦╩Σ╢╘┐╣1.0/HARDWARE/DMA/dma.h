#ifndef __DMA_H
#define __DMA_H
#include "sys.h"

void Dma_Init(void);
void ADC_LR(void);
uint8_t ADC_Sensor(uint16_t sensor);

#endif
