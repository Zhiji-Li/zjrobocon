#include "dma.h"

uint16_t Left[8] = {0};
uint16_t Right[8] = {0};
uint16_t Sensor[16] = {0};

void Dma_Init(void)
{
    DMA_InitTypeDef DMA_InitStructure;
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA2, ENABLE); 
	
    DMA_InitStructure.DMA_PeripheralBaseAddr = ((u32)ADC1+0x4c);	
    DMA_InitStructure.DMA_Memory0BaseAddr = (u32)Sensor;  
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;	
    DMA_InitStructure.DMA_BufferSize = 16;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable; 
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
	DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;	
	DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;
	DMA_InitStructure.DMA_Priority = DMA_Priority_High;
    DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Disable;
    DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_HalfFull;
    DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;
    DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;  
    DMA_InitStructure.DMA_Channel = DMA_Channel_0;
	DMA_Init(DMA2_Stream0, &DMA_InitStructure);
	
    DMA_Cmd(DMA2_Stream0, ENABLE);
}

void ADC_LR(void)
{
	Left[0] = Sensor[0];
	Left[1] = Sensor[1];
	Left[2] = Sensor[2];
	Left[3] = Sensor[3];
	Left[4] = Sensor[4];
	Left[5] = Sensor[5];
	Left[6] = Sensor[6];
	Left[7] = Sensor[7];
	
	Right[7] = Sensor[8];
	Right[6] = Sensor[9];
	Right[5] = Sensor[10];
	Right[4] = Sensor[11];
	Right[3] = Sensor[12];
	Right[2] = Sensor[13];
	Right[1] = Sensor[14];
	Right[0] = Sensor[15];
}
