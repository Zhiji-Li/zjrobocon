#ifndef __SENSOR_H
#define __SENSOR_H
#include "sys.h"

//�ڵװ���:ѹ��:0
#define front_1       PEin(1)
#define front_2       PEin(0)
#define front_3       PEin(3)
#define front_4       PEin(2)
#define front_5       PEin(5)
#define front_6       PEin(4)
#define front_7       PEin(7)
#define front_8       PEin(6)

#define behind_8      PEin(9)
#define behind_7      PEin(8)
#define behind_6      PEin(11)
#define behind_5      PEin(10)
#define behind_4      PEin(13)
#define behind_3      PEin(12)
#define behind_2      PEin(15)
#define behind_1      PEin(14)

void Sensor_Init(void);

#endif
