#include "led.h"

void led_gpio_init(void)
{	
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
    GPIO_InitTypeDef  GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT; //��ͨ���ģʽ
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; //�������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOF, &GPIO_InitStructure);
    
    GPIO_SetBits(GPIOF, GPIO_Pin_15);
}

void led_on(void)
{
	GPIO_ResetBits(GPIOF, GPIO_Pin_15);
}

void led_off(void)
{
	GPIO_SetBits(GPIOF, GPIO_Pin_15);
}

void led_turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOF, GPIO_Pin_15) == 0)
	{
		GPIO_SetBits(GPIOF, GPIO_Pin_15);
	}
	else
	{
		GPIO_ResetBits(GPIOF, GPIO_Pin_15);
	}
}
