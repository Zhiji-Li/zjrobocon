#ifndef __LED_H
#define __LED_H
#include "sys.h"

void led_gpio_init(void);
void led_on(void);
void led_off(void);
void led_turn(void);

#endif
