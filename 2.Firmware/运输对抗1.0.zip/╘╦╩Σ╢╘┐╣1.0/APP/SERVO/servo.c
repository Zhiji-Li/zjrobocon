#include "servo.h"

//reset,code:00
void servo_rest(void)
{
    int servoflag0 = 1;
    int i;
    if(Group1_1 == 0)
    {
        servoflag0 = 0;
    }
    while(servoflag0 == 1)
    {
        runActionGroup(0, 1);
        receiveHandle(); //���մ���
        for(i = 0; i < 1000; i ++)
        {
            receiveHandle(); //���մ���
            delay_ms(1);
        }
        if(Group2_1 == 0)
        {
            servoflag0 = 0;
            Task ++;
        }
    }
}

//����צ��������,code:01
void servo_PutPush(void)
{
    int servoflag1 = 1;
    int i;
    if(Group1_1 == 1)
    {
        servoflag1 = 0;
    }
    while(servoflag1 == 1)
    {
        runActionGroup(1, 1);
        receiveHandle(); //���մ���
        for(i = 0; i < 1000; i ++)
        {
            receiveHandle(); //���մ���
            delay_ms(1);
        }
        if(Group2_1 == 1)
        {
            servoflag1 = 0;
            Task ++;
        }
    }
}

//ץ��̧��λ,code:02
void servo_take(void)
{
    int servoflag2 = 1;
    int i;
    if(Group1_1 == 2)
    {
        servoflag2 = 0;
    }
    while(servoflag2 == 1)
    {
        runActionGroup(2, 1);
        receiveHandle(); //���մ���
        for(i = 0; i < 1000; i ++)
        {
            receiveHandle(); //���մ���
            delay_ms(1);
        }
        if(Group2_1 == 2)
        {
            servoflag2 = 0;
            Task ++;
        }
    }
}

//2�����׻�,code:03
void servo_2T(void)
{
    int servoflag3 = 1;
    int i;
    if(Group1_1 == 3)
    {
        servoflag3 = 0;
    }
    while(servoflag3 == 1)
    {
        runActionGroup(3, 1);
        receiveHandle(); //���մ���
        for(i = 0; i < 1000; i ++)
        {
            receiveHandle(); //���մ���
            delay_ms(1);
        }
        if(Group2_1 == 3)
        {
            servoflag3 = 0;
            Task ++;
        }
    }
}

//3�����׻�,code:04
void servo_3T(void)
{
    int servoflag4 = 1;
    int i;
    if(Group1_1 == 4)
    {
        servoflag4 = 0;
    }
    while(servoflag4 == 1)
    {
        runActionGroup(4, 1);
        receiveHandle(); //���մ���
        for(i = 0; i < 1000; i ++)
        {
            receiveHandle(); //���մ���
            delay_ms(2);
        }
        if(Group2_1 == 4)
        {
            servoflag4 = 0;
            Task ++;
        }
    }
}

//ץ���滷,code:05
void servo_power(void)
{
    int servoflag5 = 1;
    int i;
    if(Group1_1 == 5)
    {
        servoflag5 = 0;
    }
    while(servoflag5 == 1)
    {
        runActionGroup(5, 1);
        receiveHandle(); //���մ���
        for(i = 0; i < 1000; i ++)
        {
            receiveHandle(); //���մ���
            delay_ms(1);
        }
        if(Group2_1 == 5)
        {
            servoflag5 = 0;
            Task ++;
        }
    }
}
