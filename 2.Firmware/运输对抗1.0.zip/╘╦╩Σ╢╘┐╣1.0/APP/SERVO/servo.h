#ifndef __SERVO_H
#define __SERVO_H
#include "sys.h"

void servo_rest(void);
void servo_PutPush(void);
void servo_take(void);
void servo_2T(void);
void servo_3T(void);
void servo_power(void);

#endif
