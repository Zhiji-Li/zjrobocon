#ifndef __MOVE_H
#define __MOVE_H
#include "sys.h"

void move_Sspin(float angle);
void move_Nspin(float angle);
void Start(void);
void move_forward(uint8_t cross, uint16_t speed, uint8_t place);
void move_backward(uint8_t cross, uint16_t speed, uint8_t place);
void move_left(uint8_t cross, uint16_t speed, uint8_t place);
void move_right(uint8_t cross, uint16_t speed, uint8_t place);
void move_TopRight(uint8_t cross, uint16_t speed, uint8_t place);
void move_TopLeft(uint8_t cross, uint16_t speed, uint8_t place);
void move_DownLeft(uint8_t cross, uint16_t speed, uint8_t place);

#endif
