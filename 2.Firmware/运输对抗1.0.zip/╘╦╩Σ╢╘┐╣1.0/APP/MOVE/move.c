#include "move.h"

int CROSS, a = 0;
float b = 0.0f;

void Start(void)
{
	Motor_Forward();
	TIM_SetCompare1(TIM3, 300 * 0.99);
    TIM_SetCompare2(TIM3, 300 * 0.99);
    TIM_SetCompare3(TIM3, 300);
    TIM_SetCompare4(TIM3, 300);
	if((Left[3] <= 1000) || (Left[4] <= 1000) || (Left[5] <= 1000))
	{
		Task ++;
		Motor_Stop();
	}
}

void move_Sspin(float angle)
{	
	Motor_Sspin();		//˳ʱ��
    TIM_SetCompare1(TIM3, 300);
    TIM_SetCompare2(TIM3, 300);
    TIM_SetCompare3(TIM3, 300 * 0.95);
    TIM_SetCompare4(TIM3, 300 * 0.95);
	
    if(Angle >= 5.0f)
    {
        b = Angle - angle - 9.0f;
        if(b <= 0.0f)
        {
            Motor_Stop();
            angle = 0.0f;
            b = 0.0f;
            Task ++;
        }
    }
}

void move_Nspin(float angle)
{
    Motor_Nspin();		//��ʱ��
    TIM_SetCompare1(TIM3, 300);
    TIM_SetCompare2(TIM3, 300);
    TIM_SetCompare3(TIM3, 300 * 0.95);
    TIM_SetCompare4(TIM3, 300 * 0.95);
    
    if(Angle >= angle - 4.0f && Angle <= angle + 4.0f)
    {
        Motor_Stop();
        angle = 0.0f;
        Task ++;
    }
}

void move_forward(uint8_t cross, uint16_t speed, uint8_t place)
{
    Motor_Forward();
    if(a == 0)
    {
        CROSS = cross;
        a = 1;
    }
    if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && front_7 == 0 && CROSS > 0)
    {
        if(a == 1)
        {
            CROSS--;
            a = 2;
        }
        TIM_SetCompare1(TIM3, speed * 0.99);
        TIM_SetCompare2(TIM3, speed * 0.99);
        TIM_SetCompare3(TIM3, speed);
        TIM_SetCompare4(TIM3, speed);

    }
    else if(CROSS > 0)
    {
        if(behind_2 == 0 && behind_3 == 0 && behind_4 == 0 && behind_5 == 0 && behind_6 == 0 && behind_7 == 0)
        {
            a = 1;
        }
		//�ڵװ���:ѹ��:0
        if(front_1 == 0)
        {
			TIM_SetCompare1(TIM3, speed * 0.4);
            TIM_SetCompare2(TIM3, speed * 0.4);
            TIM_SetCompare3(TIM3, speed * 1.4);
            TIM_SetCompare4(TIM3, speed * 1.4);
        }
		else if(front_2 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 0.5);
            TIM_SetCompare2(TIM3, speed * 0.5);
            TIM_SetCompare3(TIM3, speed * 1.3);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
		else if(front_3 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 0.7);
            TIM_SetCompare2(TIM3, speed * 0.7);
            TIM_SetCompare3(TIM3, speed * 1.6);
            TIM_SetCompare4(TIM3, speed * 1.6);
        }
		else if(front_4 == 1)
        {
            TIM_SetCompare1(TIM3, speed * 1.3);
            TIM_SetCompare2(TIM3, speed * 1.3);
            TIM_SetCompare3(TIM3, speed * 0.8);
            TIM_SetCompare4(TIM3, speed * 0.8);
        }
        else if(front_5 == 1)
        {
            TIM_SetCompare1(TIM3, speed * 0.8);
            TIM_SetCompare2(TIM3, speed * 0.8);
            TIM_SetCompare3(TIM3, speed * 1.3);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
        else if(front_6 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 1.6);
            TIM_SetCompare2(TIM3, speed * 1.6);
            TIM_SetCompare3(TIM3, speed * 0.75);
            TIM_SetCompare4(TIM3, speed * 0.75);
        }
        else if(front_7 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 1.7);
            TIM_SetCompare2(TIM3, speed * 1.7);
            TIM_SetCompare3(TIM3, speed * 0.7);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
        else if(front_8 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 1.8);
            TIM_SetCompare2(TIM3, speed * 1.8);
            TIM_SetCompare3(TIM3, speed * 0.7);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
        //����
        else if(front_4 == 0 && front_5 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 0.99);
            TIM_SetCompare2(TIM3, speed * 0.99);
            TIM_SetCompare3(TIM3, speed);
            TIM_SetCompare4(TIM3, speed);
        }
    }
    else if(CROSS == 0)
    {
        if(((Left[3] <= 1000) || (Left[4] <= 1000) || (Left[5] <= 1000)) && place == 2)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && place == 1)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(behind_2 == 0 && behind_3 == 0 && behind_4 == 0 && behind_5 == 0 && behind_6 == 0 && behind_7 == 0 && place == 3)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(behind_2 == 0 && behind_3 == 0 && behind_4 == 0 && behind_5 == 0 && behind_6 == 0 && behind_7 == 0 && place == 4)
        {
            a = 0;
            Task ++;
        }
    }
}

void move_backward(uint8_t cross, uint16_t speed, uint8_t place)
{
    Motor_Backward();
    if(a == 0)
    {
        CROSS = cross;
        a = 1;
    }
    if(behind_2 == 0 && behind_3 == 0 && behind_4 == 0 && behind_5 == 0 && behind_6 == 0 && behind_7 == 0 && CROSS > 0)
    {
		if(a == 1)
        {
			CROSS--;
            a = 2;
        }
        TIM_SetCompare1(TIM3, speed * 0.99);
        TIM_SetCompare2(TIM3, speed * 0.99);
        TIM_SetCompare3(TIM3, speed);
        TIM_SetCompare4(TIM3, speed);
      }
	else if(CROSS > 0)
    {
		if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && front_7 == 0)
        {
			a = 1;
        }
        //�ڵװ���:ѹ��:0
		if(behind_1 == 0)
        {
			TIM_SetCompare1(TIM3, speed * 0.4);
            TIM_SetCompare2(TIM3, speed * 0.4);
            TIM_SetCompare3(TIM3, speed * 1.4);
            TIM_SetCompare4(TIM3, speed * 1.4);
        }
		else if(behind_2 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 0.5);
            TIM_SetCompare2(TIM3, speed * 0.5);
            TIM_SetCompare3(TIM3, speed * 1.3);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
		else if(behind_3 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 0.7);
            TIM_SetCompare2(TIM3, speed * 0.7);
            TIM_SetCompare3(TIM3, speed * 1.7);
            TIM_SetCompare4(TIM3, speed * 1.7);
        }
		else if(behind_4 == 1)
        {
            TIM_SetCompare1(TIM3, speed * 1.3);
            TIM_SetCompare2(TIM3, speed * 1.3);
            TIM_SetCompare3(TIM3, speed * 0.8);
            TIM_SetCompare4(TIM3, speed * 0.8);
        }
        else if(behind_5 == 1)
        {
            TIM_SetCompare1(TIM3, speed * 0.8);
            TIM_SetCompare2(TIM3, speed * 0.8);
            TIM_SetCompare3(TIM3, speed * 1.3);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
        else if(behind_6 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 1.6);
            TIM_SetCompare2(TIM3, speed * 1.6);
            TIM_SetCompare3(TIM3, speed * 0.75);
            TIM_SetCompare4(TIM3, speed * 0.75);
        }
        else if(behind_7 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 1.7);
            TIM_SetCompare2(TIM3, speed * 1.7);
            TIM_SetCompare3(TIM3, speed * 0.7);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
        else if(behind_8 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 1.8);
            TIM_SetCompare2(TIM3, speed * 1.8);
            TIM_SetCompare3(TIM3, speed * 0.7);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
		//normal
        else if(behind_4 == 0 && behind_5 == 0)
        {
            TIM_SetCompare1(TIM3, speed * 0.99);
            TIM_SetCompare2(TIM3, speed * 0.99);
            TIM_SetCompare3(TIM3, speed);
            TIM_SetCompare4(TIM3, speed);
        }
    }
    else if(CROSS == 0)
    {
        if(((Left[3] <= 1000) || (Left[4] <= 1000) || (Left[5] <= 1000)) && place == 2)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && place == 3)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(behind_2 == 0 && behind_3 == 0 && behind_4 == 0 && behind_5 == 0 && behind_6 == 0 && behind_7 == 0 && place == 1)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && place == 4)
        {
            a = 0;
            Task ++;
        }
		//������һ�㵽�м�
		else if(((Left[3] <= 1000) || (Left[4] <= 1000) || (Left[5] <= 1000)) && place == 5)
        {
            a = 0;
            Task ++;
			Motor_Stop();
        }
    }
}

void move_left(uint8_t cross, uint16_t speed, uint8_t place)
{
    Motor_Left();
    if(a == 0)
    {
        CROSS = cross;
        a = 1;
    }
    if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000 && CROSS > 0)
    {
		if(a == 1)
		{
			CROSS--;
			a = 2;
		}
		TIM_SetCompare1(TIM3, speed * 0.99);
		TIM_SetCompare2(TIM3, speed * 0.99);
		TIM_SetCompare3(TIM3, speed);
		TIM_SetCompare4(TIM3, speed);
    }
    else if(CROSS > 0)
    {
        if(Right[1] <= 1000 && Right[2] <= 1000 && Right[3] <= 1000 && Right[4] <= 1000 && Right[5] <= 1000 && Right[6] <= 1000)
        {    
			a = 1;  
        }
		//AD<=1000:ѹ����;AD>=1000:ѹ��ɫ
        if(Left[0] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.4);
            TIM_SetCompare2(TIM3, speed * 0.4);
            TIM_SetCompare3(TIM3, speed * 0.4);
            TIM_SetCompare4(TIM3, speed * 1.4);
        }
        else if(Left[1] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.3);
            TIM_SetCompare2(TIM3, speed * 0.5);
            TIM_SetCompare3(TIM3, speed * 0.5);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
        else if(Left[2] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.7);
            TIM_SetCompare2(TIM3, speed * 0.7);
            TIM_SetCompare3(TIM3, speed * 0.7);
            TIM_SetCompare4(TIM3, speed * 1.6);
        }
        else if(Left[3] >= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.8);
            TIM_SetCompare2(TIM3, speed * 1.3);
            TIM_SetCompare3(TIM3, speed * 1.3);
            TIM_SetCompare4(TIM3, speed * 0.8);
        }
		else if(Left[4] >= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.3);
            TIM_SetCompare2(TIM3, speed * 0.8);
            TIM_SetCompare3(TIM3, speed * 0.8);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
		else if(Left[5] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.75);
            TIM_SetCompare2(TIM3, speed * 1.6);
            TIM_SetCompare3(TIM3, speed * 1.6);
            TIM_SetCompare4(TIM3, speed * 0.75);
        }
		else if(Left[6] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.7);
            TIM_SetCompare2(TIM3, speed * 1.7);
            TIM_SetCompare3(TIM3, speed * 1.7);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
		else if(Left[6] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.7);
            TIM_SetCompare2(TIM3, speed * 1.8);
            TIM_SetCompare3(TIM3, speed * 1.8);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
		//normol
        else if(Left[3] <= 1000 && Left[4] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.99);
            TIM_SetCompare2(TIM3, speed * 0.99);
            TIM_SetCompare3(TIM3, speed);
            TIM_SetCompare4(TIM3, speed);
        }
    }
    else if(CROSS == 0)
    { 
       if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000 && place == 1)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(front_4 == 0 && front_5 == 0 && place == 2)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(Right[1] <= 1000 && Right[2] <= 1000 && Right[3] <= 1000 && Right[4] <= 1000 && Right[5] <= 1000 && Right[6] <= 1000 && place == 3)
        {
            a = 0;
            Task ++;
            Motor_Stop();
        }
        else if(((front_4 == 0 && front_5 == 0) || (behind_4 == 0 && behind_5 == 0)) && place == 4)
        {
            a = 0;
            Task ++;
        }
    }
}

void move_right(uint8_t cross, uint16_t speed, uint8_t place)
{
    Motor_Right();
    if(a == 0)
    {
        CROSS = cross;
        a = 1;
    }
    if(Right[1] <= 1000 && Right[2] <= 1000 && Right[3] <= 1000 && Right[4] <= 1000 && Right[5] <= 1000 && Right[6] <= 1000 && CROSS > 0)
    {
		if(a == 1)
		{
			CROSS--;
			a = 2;
		}
		TIM_SetCompare1(TIM3, speed * 0.99);
		TIM_SetCompare2(TIM3, speed * 0.99);
		TIM_SetCompare3(TIM3, speed);
		TIM_SetCompare4(TIM3, speed);
    }
    else if(CROSS > 0)
    {
        if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000)
        {    
			a = 1;  
        }
		//AD<=1000:ѹ����;AD>=1000:ѹ��ɫ
        if(Right[0] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.4);
            TIM_SetCompare2(TIM3, speed * 0.4);
            TIM_SetCompare3(TIM3, speed * 0.4);
            TIM_SetCompare4(TIM3, speed * 1.4);
        }
        else if(Right[1] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.3);
            TIM_SetCompare2(TIM3, speed * 0.5);
            TIM_SetCompare3(TIM3, speed * 0.5);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
        else if(Right[2] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.7);
            TIM_SetCompare2(TIM3, speed * 0.7);
            TIM_SetCompare3(TIM3, speed * 0.7);
            TIM_SetCompare4(TIM3, speed * 1.6);
        }
        else if(Right[3] >= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.8);
            TIM_SetCompare2(TIM3, speed * 1.3);
            TIM_SetCompare3(TIM3, speed * 1.3);
            TIM_SetCompare4(TIM3, speed * 0.8);
        }
		else if(Right[4] >= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 1.3);
            TIM_SetCompare2(TIM3, speed * 0.8);
            TIM_SetCompare3(TIM3, speed * 0.8);
            TIM_SetCompare4(TIM3, speed * 1.3);
        }
		else if(Right[5] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.75);
            TIM_SetCompare2(TIM3, speed * 1.6);
            TIM_SetCompare3(TIM3, speed * 1.6);
            TIM_SetCompare4(TIM3, speed * 0.75);
        }
		else if(Right[6] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.7);
            TIM_SetCompare2(TIM3, speed * 1.7);
            TIM_SetCompare3(TIM3, speed * 1.7);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
		else if(Right[6] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.7);
            TIM_SetCompare2(TIM3, speed * 1.8);
            TIM_SetCompare3(TIM3, speed * 1.8);
            TIM_SetCompare4(TIM3, speed * 0.7);
        }
		//normol
        else if(Right[3] <= 1000 && Right[4] <= 1000)
        {
            TIM_SetCompare1(TIM3, speed * 0.99);
            TIM_SetCompare2(TIM3, speed * 0.99);
            TIM_SetCompare3(TIM3, speed);
            TIM_SetCompare4(TIM3, speed);
        }
    }
    else if(CROSS == 0)
    {
        if((front_4 == 0 || front_5 == 0) && place == 2)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(((front_4 == 0 && front_5 == 0) || (behind_4 == 0 && behind_5 == 0)) && place == 4)
        {
            a = 0;
            Task++;
        }
        else if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000 && place == 3)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(Right[1] <= 1000 && Right[2] <= 1000 && Right[3] <= 1000 && Right[4] <= 1000 && Right[5] <= 1000 && Right[6] <= 1000 && place == 1)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
    }
}

void move_TopRight(uint8_t cross, uint16_t speed, uint8_t place)
{
	Motor_TopRight();
	if(a == 0)
    {
        CROSS = cross;
        a = 1;
    }
    if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && front_7 == 0 && CROSS > 0)
    {
		if(a == 1)
		{
			CROSS--;
			a = 2;
		}
		TIM_SetCompare1(TIM3, speed);
		TIM_SetCompare2(TIM3, 0);
		TIM_SetCompare3(TIM3, speed);
		TIM_SetCompare4(TIM3, 0);
    }
    else if(CROSS > 0)
    {
        if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000)
        {    
			a = 1;  
        }
		TIM_SetCompare1(TIM3, speed);
		TIM_SetCompare2(TIM3, 0);
		TIM_SetCompare3(TIM3, speed);
		TIM_SetCompare4(TIM3, 0);
    }
    else if(CROSS == 0)
    {
        if(((front_4 == 0 || front_5 == 0)&&(behind_4 == 0 || behind_5 == 0)) && place == 2)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000 && place == 3)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(Right[1] <= 1000 && Right[2] <= 1000 && Right[3] <= 1000 && Right[4] <= 1000 && Right[5] <= 1000 && Right[6] <= 1000 && place == 1)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
		//ǰѭ��ȫ��ѹ��ͣ
		if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && place == 4)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
    }
}

void move_TopLeft(uint8_t cross, uint16_t speed, uint8_t place)
{
	Motor_TopLeft();
	if(a == 0)
    {
        CROSS = cross;
        a = 1;
    }
    if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && front_7 == 0 && CROSS > 0)
    {
		if(a == 1)
		{
			CROSS--;
			a = 2;
		}
		TIM_SetCompare1(TIM3, 0);
		TIM_SetCompare2(TIM3, speed);
		TIM_SetCompare3(TIM3, 0);
		TIM_SetCompare4(TIM3, speed);
    }
    else if(CROSS > 0)
    {
        if(behind_2 == 0 && behind_3 == 0 && behind_4 == 0 && behind_5 == 0 && behind_6 == 0 && behind_7 == 0)
        {    
			a = 1;  
        }
		TIM_SetCompare1(TIM3, 0);
		TIM_SetCompare2(TIM3, speed);
		TIM_SetCompare3(TIM3, 0);
		TIM_SetCompare4(TIM3, speed);
    }
    else if(CROSS == 0)
    {
        if(((front_4 == 0 || front_5 == 0)&&(behind_4 == 0 || behind_5 == 0)) && place == 2)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000 && place == 3)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(Right[1] <= 1000 && Right[2] <= 1000 && Right[3] <= 1000 && Right[4] <= 1000 && Right[5] <= 1000 && Right[6] <= 1000 && place == 1)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
    }
}

void move_DownLeft(uint8_t cross, uint16_t speed, uint8_t place)
{
	Motor_DownLeft();
	if(a == 0)
    {
        CROSS = cross;
        a = 1;
    }
    if(front_2 == 0 && front_3 == 0 && front_4 == 0 && front_5 == 0 && front_6 == 0 && front_7 == 0 && CROSS > 0)
    {
		if(a == 1)
		{
			CROSS--;
			a = 2;
		}
		TIM_SetCompare1(TIM3, speed);
		TIM_SetCompare2(TIM3, 0);
		TIM_SetCompare3(TIM3, speed);
		TIM_SetCompare4(TIM3, 0);
    }
    else if(CROSS > 0)
    {
        if(behind_2 == 0 && behind_3 == 0 && behind_4 == 0 && behind_5 == 0 && behind_6 == 0 && behind_7 == 0)
        {    
			a = 1;  
        }
		TIM_SetCompare1(TIM3, speed);
		TIM_SetCompare2(TIM3, 0);
		TIM_SetCompare3(TIM3, speed);
		TIM_SetCompare4(TIM3, 0);
    }
    else if(CROSS == 0)
    {
        if(((front_4 == 0 || front_5 == 0)&&(behind_4 == 0 || behind_5 == 0)) && place == 2)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(Left[1] <= 1000 && Left[2] <= 1000 && Left[3] <= 1000 && Left[4] <= 1000 && Left[5] <= 1000 && Left[6] <= 1000 && place == 3)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
        else if(Right[1] <= 1000 && Right[2] <= 1000 && Right[3] <= 1000 && Right[4] <= 1000 && Right[5] <= 1000 && Right[6] <= 1000 && place == 1)
        {
            a = 0;
            Task++;
            Motor_Stop();
        }
    }
}
