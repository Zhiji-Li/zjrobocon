#include "test.h"

void ADC_L_Test(void)
{
	OLED_ShowNum(1, 1, Left[0], 4);
	OLED_ShowNum(1, 7, Left[1], 4);
	OLED_ShowNum(2, 1, Left[2], 4);
	OLED_ShowNum(2, 7, Left[3], 4);
	OLED_ShowNum(3, 1, Left[4], 4);
	OLED_ShowNum(3, 7, Left[5], 4);
	OLED_ShowNum(4, 1, Left[6], 4);
	OLED_ShowNum(4, 7, Left[7], 4);
}
void ADC_R_Test(void)
{
	OLED_ShowNum(1, 1, Right[0], 4);
	OLED_ShowNum(1, 7, Right[1], 4);
	OLED_ShowNum(2, 1, Right[2], 4);
	OLED_ShowNum(2, 7, Right[3], 4);
	OLED_ShowNum(3, 1, Right[4], 4);
	OLED_ShowNum(3, 7, Right[5], 4);
	OLED_ShowNum(4, 1, Right[6], 4);
	OLED_ShowNum(4, 7, Right[7], 4);
}

void Sensor_Test(void)
{
	OLED_ShowNum(1, 1, front_1, 1);
	OLED_ShowNum(1, 2, front_2, 1);
	OLED_ShowNum(1, 3, front_3, 1);
	OLED_ShowNum(1, 4, front_4, 1);
	OLED_ShowNum(1, 5, front_5, 1);
	OLED_ShowNum(1, 6, front_6, 1);
	OLED_ShowNum(1, 7, front_7, 1);
	OLED_ShowNum(1, 8, front_8, 1);
	
	OLED_ShowNum(2, 1, behind_1, 1);
	OLED_ShowNum(2, 2, behind_2, 1);
	OLED_ShowNum(2, 3, behind_3, 1);
	OLED_ShowNum(2, 4, behind_4, 1);
	OLED_ShowNum(2, 5, behind_5, 1);
	OLED_ShowNum(2, 6, behind_6, 1);
	OLED_ShowNum(2, 7, behind_7, 1);
	OLED_ShowNum(2, 8, behind_8, 1);
}

void Motor_Test(void)
{
	//Motor_Forward();
	//Motor_Backward();
	//Motor_Left();
	//Motor_Right();
	//Motor_Nspin();	//��ʱ��
	//Motor_Sspin();		//˳ʱ��
	Motor_TopRight();

    TIM_SetCompare1(TIM3, 700);
    TIM_SetCompare2(TIM3, 0);
    TIM_SetCompare3(TIM3, 700);
    TIM_SetCompare4(TIM3, 0);
}

void Test_Task(void)
{
    switch(Task)
    {
        case 0: move_forward(1, 400, 2); break;		//·��,�ٶ�,1:ǰ,2:��,3:��ͣ,4:��ͣ
		case 1: servo_PutPush(); break;
		case 2: move_forward(1, 400, 2); break;
        case 3: runActionGroup(2, 1); Task=4; break;
		case 4: move_forward(1, 400, 2); break;
		case 5: delay = 1; break;
		case 6: move_right(1, 300, 2);
        case 7: delay = 1; break;
        case 8: move_forward(1, 400, 2); break;
        case 9: servo_power(); break;
        //case 10: servo_rest(); break;
        
        case 16: Motor_Stop(); break;
            
        default:
            break;
    }
}

void Test_Task2(void)
{
    switch(Task)
    {
        case 0: move_TopRight(1, 700, 2); break;
        case 1: delay = 1; break;
        case 2: move_TopLeft(1, 700, 2); break;
        case 3: delay = 1; break;
        case 4: move_TopRight(1, 700, 2); break;
        case 5: delay = 1; break;
        case 6: move_TopLeft(1, 700, 2); break;
        case 7: delay = 1; break;
        case 8: move_right(1, 500, 2); break;
        case 9: move_backward(1, 500, 4); break;
		case 10: move_backward(3, 880, 4); break;
		case 11: move_backward(1, 500, 2); break;
		case 12: delay = 1; break;
		case 13: move_left(1, 500, 2); break;
        
        case 14: Motor_Stop(); break;
            
        default:
            break;
    }
}
