#ifndef __TEST_H
#define __TEST_H
#include "sys.h"

void ADC_L_Test(void);
void ADC_R_Test(void);
void Sensor_Test(void);
void Motor_Test(void);
void Test_Task(void);
void Test_Task2(void);

#endif

