#include "task.h"

void Sys_Init(void)
{
	SystemInit();
	delay_init(168);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	uart1_init(9600);		//servo
	uart2_init(9600);		//jy901
	uart3_init(38400);		//Bluetooth
}

void Hardware_Init(void)
{
	jy901_Init();
	delay_ms(1000);
	delay_ms(1000);			//wait JY901 init
	pwm_init(900, 10);
	//TIM4_Init();
	motor_gpio_init();
	Adc_Init();
	Dma_Init();
	oled_init();
	Sensor_Init();
	led_gpio_init();
	KEY_Init();
	Select_Key_Init();

	runActionGroup(0, 1);	//servo reset
	delay_ms(800);
	led_on();
	
	//Task = 91;			//Debug val
}

/*--------------------------------------*
			��ʱ����־λ��ʱ
  --------------------------------------*/
void DelayTime(void)
{
    if (delay_time >= 1000 && delay == 1)
    {
        delay_time = 0;
        Task++;
        delay = 0;
    }
	else if (delay_time >= 100 && delay == 2)
	{
		delay_time = 0;
		Task++;
		delay = 0;
	}
}

#define FORWARD_SPEED 400
#define BACKWARD_SPEED 320
#define TOPRIGHT_SPEED 400

#define BACKWARD_MAX_SPEED 500
#define FORWARD_MAX_SPEED 600

#define LEFT_SPEED 300
#define RIGHT_SPEED 300

void Task_Run(void)
{
	switch(Task)
    {
		case 0: move_Sspin(270); break;
		case 1: delay = 1; break;
		case 2: move_forward(1, FORWARD_SPEED, 2); break;
		case 3: servo_PutPush(); break;
		case 4: move_forward(1, FORWARD_SPEED, 2); break;
        case 5: runActionGroup(2, 1); Task = 6; break;
		
		case 6: move_forward(1, FORWARD_SPEED, 4); break;
		case 7: move_forward(2, FORWARD_MAX_SPEED, 4); break;
		case 8: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 9: servo_2T(); break;
		case 10: servo_rest(); break;
		
		case 11: move_backward(2, BACKWARD_SPEED, 2); break;
		case 12: move_Nspin(359); break;
		case 13: delay = 1; break;
		
		case 14: move_forward(1, FORWARD_SPEED, 2); break;
		case 15: servo_PutPush(); break;
		case 16: move_forward(1, FORWARD_SPEED, 2); break;
        case 17: servo_take(); break;
		case 18: delay = 1; break;
		case 19: move_right(1, RIGHT_SPEED, 2); break;
		case 20: move_forward(2, FORWARD_SPEED, 3); break;
		case 21: servo_3T(); break;
		case 22: servo_rest(); break;
		case 23: move_backward(0, BACKWARD_SPEED, 5); break;//������һ�㵽�м�
		case 24: move_Sspin(270); break;
		case 25: servo_PutPush(); break;
		case 26: move_forward(1, FORWARD_SPEED, 2); break;
		case 27: servo_take(); break;
		
		case 28: move_backward(1, BACKWARD_SPEED, 2); break;
		case 29: move_Nspin(359); break;
		case 30: move_backward(1, BACKWARD_SPEED, 2); break;
		case 31: delay = 1; break;
		case 32: move_forward(1, FORWARD_SPEED, 3); break;
		case 33: servo_3T(); break;
		case 34: servo_rest(); break;
		case 35: move_backward(0, BACKWARD_SPEED, 2); break;
		case 36: move_Nspin(90); break;
		case 37: delay = 1; break;
		case 38: servo_PutPush(); break;
		case 39: move_forward(1, FORWARD_SPEED, 2); break;
		case 40: servo_take(); break;
		case 41: move_backward(1, BACKWARD_SPEED, 2); break;
		case 42: move_Nspin(180); break;
		case 43: delay = 1; break;
		
		case 44: move_forward(1, FORWARD_SPEED, 4); break;
		case 45: move_forward(3, FORWARD_MAX_SPEED, 4); break;
		case 46: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 47: servo_2T(); break;
		case 48: servo_rest(); break;
		
		case 49: move_backward(1, BACKWARD_SPEED, 4); break;
		case 50: move_backward(1, BACKWARD_MAX_SPEED, 4); break;
		case 51: move_backward(1, BACKWARD_SPEED, 2); break;
		
		case 52: move_Sspin(90); break;
		case 53: move_forward(2, FORWARD_SPEED, 2); break;
		case 54: servo_PutPush(); break;
		case 55: move_forward(1, FORWARD_SPEED, 2); break;
        case 56: servo_take(); break;
		case 57: delay = 1; break;
		
		case 58: move_backward(3, BACKWARD_SPEED, 2); break;
		case 59: move_Nspin(180); break;
		case 60: delay = 1; break;
		case 61: move_forward(3, FORWARD_SPEED, 2); break;
		case 62: servo_2T(); break;
		case 63: servo_rest(); break;
		
		case 64: move_backward(1, BACKWARD_SPEED, 4); break;
		case 65: move_backward(1, BACKWARD_MAX_SPEED, 4); break;
		case 66: move_backward(1, BACKWARD_SPEED, 2); break;
		case 67: move_Sspin(90); break;
		case 68: delay = 1; break;
		
		case 69: move_forward(1, FORWARD_SPEED, 4); break;
		case 70: move_forward(2, FORWARD_MAX_SPEED, 4); break;
		case 71: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 72: servo_PutPush(); break;
		case 73: move_forward(1, FORWARD_SPEED, 2); break;
        case 74: servo_take(); break;
		
		case 75: move_backward(1, BACKWARD_SPEED, 4); break;
		case 76: move_backward(3, BACKWARD_MAX_SPEED, 4); break;
		case 77: move_backward(1, BACKWARD_SPEED, 2); break;
		
		case 78: move_Nspin(180); break;
		case 79: move_forward(2, FORWARD_SPEED, 2); break;
		case 80: move_Nspin(270); break;
		case 81: move_backward(1, BACKWARD_SPEED, 2); break;
		case 82: delay = 1; break;
		case 83: move_forward(2, FORWARD_SPEED, 2); break;
		
		case 84: servo_2T(); break;
		case 85: servo_rest(); break;
		
		case 86: move_backward(1, BACKWARD_SPEED, 4); break;
		case 87: move_backward(2, BACKWARD_MAX_SPEED, 4); break;
		case 88: move_backward(1, BACKWARD_SPEED, 2); break;
		
		case 89: move_Nspin(359); break;
		case 90: delay = 1; break;
		
		case 91: move_forward(1, FORWARD_SPEED, 4); break;
		case 92: move_forward(1, FORWARD_MAX_SPEED, 4); break;
		case 93: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 94: servo_PutPush(); break;
		case 95: move_forward(1, FORWARD_SPEED, 2); break;
        case 96: servo_take(); break;
		
		case 97: move_backward(1, BACKWARD_SPEED, 4); break;
		case 98: move_backward(2, BACKWARD_MAX_SPEED, 4); break;
		case 99: move_backward(1, BACKWARD_SPEED, 2); break;
		
		case 100: move_Sspin(270); break;
		case 101: delay = 1; break;
		
		case 102: move_forward(1, FORWARD_SPEED, 4); break;
		case 103: move_forward(1, FORWARD_MAX_SPEED, 4); break;
		case 104: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 105: move_TopRight(0, TOPRIGHT_SPEED, 4); break;
		case 106: servo_2T(); break;
		case 107: servo_rest(); break;
		
		case 108: move_DownLeft(0, TOPRIGHT_SPEED, 2); break;
		
		case 109: move_backward(1, BACKWARD_SPEED, 2); break;
		case 110: move_Nspin(359); break;
		case 111: delay = 1; break;
		
		case 112: move_forward(1, FORWARD_SPEED, 4); break;
		case 113: move_forward(3, FORWARD_MAX_SPEED, 4); break;
		case 114: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 115: servo_PutPush(); break;
		case 116: move_forward(1, FORWARD_SPEED, 2); break;
        case 117: servo_take(); break;
		
		case 118: move_backward(1, BACKWARD_SPEED, 4); break;
		case 119: move_backward(4, BACKWARD_MAX_SPEED, 4); break;
		case 120: move_backward(1, BACKWARD_SPEED, 2); break;
		
		case 121: move_Sspin(270); break;
		case 122: delay = 1; break;
		
		case 123: move_forward(1, FORWARD_SPEED, 2); break;
		case 124: move_TopRight(0, TOPRIGHT_SPEED, 4); break;
		case 125: servo_2T(); break;
		case 126: servo_rest(); break;
		
		case 127: move_DownLeft(0, TOPRIGHT_SPEED, 2); break;
		
        default:
            break;
	}
}

void Task_One(void)
{
	switch(Task)
    {
		//case 0: Task = 1; break;
		case 0: Start(); break;
		//(3,2)---(7,2)�׵�2����
		case 1: move_Sspin(270); break;
		case 2: delay = 1; break;
		case 3: move_forward(1, FORWARD_SPEED, 2); uart3WriteBuf(start, 3); break;
		case 4: servo_PutPush(); break;
		case 5: move_forward(1, FORWARD_SPEED, 2); break;
        case 6: runActionGroup(2, 1); Task = 7; break;
		
		case 7: move_forward(1, FORWARD_SPEED, 4); break;
		case 8: move_forward(2, FORWARD_MAX_SPEED, 4); break;
		case 9: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 10: servo_2T(); break;
		case 11: servo_rest(); break;
		
		//(5,4)---(7,2)�׵�2����
		case 12: move_backward(2, BACKWARD_SPEED, 2); break;
		case 13: move_Nspin(359); break;
		case 14: delay = 1; break;
		case 15: move_forward(1, FORWARD_SPEED, 2); break;
		case 16: servo_PutPush(); break;
		case 17: move_forward(1, FORWARD_SPEED, 2); break;
        case 18: servo_take(); break;
		case 19: move_backward(2, BACKWARD_SPEED, 2); break;
		case 20: move_Sspin(270); break;
		case 21: delay = 1; break;
		case 22: move_forward(2, FORWARD_SPEED, 2); break;
		
		case 23: servo_2T(); break;
		case 24: servo_rest(); break;
		
		//(5,6)---(6,7)�׵�3����
		case 25: move_backward(2, BACKWARD_SPEED, 2); break;
		case 26: move_Nspin(359); break;
		case 27: delay = 1; break;
		
		case 28: move_forward(1, FORWARD_SPEED, 4); break;
		case 29: move_forward(1, FORWARD_MAX_SPEED, 4); break;
		case 30: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 31: servo_PutPush(); break;
		case 32: move_forward(1, FORWARD_SPEED, 2); break;
        case 33: servo_take(); break;
		
		case 34: move_backward(1, BACKWARD_SPEED, 2); break;
		case 35: delay = 1; break;
		case 36: move_right(1, RIGHT_SPEED, 2); break;
		case 37: delay = 1; break;
		case 38: move_forward(1, FORWARD_SPEED, 3); break;
		case 39: servo_3T(); break;
		case 40: servo_rest(); break;
		
		case 41: move_backward(0, BACKWARD_SPEED, 5); break;//������һ�㵽�м�
		case 42: move_Sspin(270); break;
		case 43: servo_PutPush(); break;
		case 44: move_forward(1, FORWARD_SPEED, 2); break;
		case 45: servo_take(); break;
		
		case 46: move_backward(1, BACKWARD_SPEED, 2); break;
		case 47: move_Nspin(359); break;
		case 48: move_backward(1, BACKWARD_SPEED, 2); break;
		case 49: delay = 1; break;
		case 50: move_forward(1, FORWARD_SPEED, 3); break;
		case 51: servo_3T(); break;
		case 52: servo_rest(); break;
		
		//(5,8)---(6,2)ץ��1����
		case 53: move_backward(0, BACKWARD_SPEED, 5); break;//������һ�㵽�м�
		case 54: delay = 1; break;
		case 55: move_left(1, LEFT_SPEED, 2); break;
		
		case 56: move_forward(1, FORWARD_SPEED, 2); break;
		case 57: servo_PutPush(); break;
		case 58: move_forward(1, FORWARD_SPEED, 2); break;
        case 59: servo_take(); break;
		
		case 60: move_backward(1, BACKWARD_SPEED, 4); break;
		case 61: move_backward(4, BACKWARD_MAX_SPEED, 4); break;
		case 62: move_backward(1, BACKWARD_SPEED, 2); break;
		
		case 63: move_right(1, RIGHT_SPEED, 2); break;
		case 64: move_Sspin(270); break;
		case 65: delay = 1; break;
		
		case 66: move_TopRight(0, TOPRIGHT_SPEED, 4); break;
		case 67: servo_2T(); break;
		case 68: servo_rest(); break;
		
		//(3,4)---(6,2)ץ��1����
		case 69: move_DownLeft(0, TOPRIGHT_SPEED, 2); break;
		case 70: delay = 1; break;
		
		case 71: move_backward(1, BACKWARD_SPEED, 4); break;
		case 72: move_backward(1, BACKWARD_MAX_SPEED, 4); break;
		case 73: move_backward(1, BACKWARD_SPEED, 2); break;
		
		case 74: move_Nspin(359); break;
		case 75: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 76: servo_PutPush(); break;
		case 77: move_forward(1, FORWARD_SPEED, 2); break;
        case 78: servo_take(); break;
		
		case 79: move_backward(2, BACKWARD_SPEED, 2); break;
		case 80: move_Sspin(270); break;
		case 81: delay = 1; break;
		case 82: move_forward(1, FORWARD_SPEED, 4); break;
		case 83: move_forward(1, FORWARD_MAX_SPEED, 4); break;
		case 84: move_forward(1, FORWARD_SPEED, 2); break;
		
		case 85: move_TopRight(0, TOPRIGHT_SPEED, 4); break;
		case 86: servo_2T(); break;
		case 87: servo_rest(); break;
		
		default:
			break;
	}
}
