#ifndef __TASK_H
#define __TASK_H
#include "sys.h"

void Sys_Init(void);
void Hardware_Init(void);
void DelayTime(void);
void Task_Run(void);
void Task_One(void);

#endif

