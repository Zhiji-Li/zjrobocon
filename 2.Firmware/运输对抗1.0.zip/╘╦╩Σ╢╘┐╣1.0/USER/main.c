#include "sys.h"

int Task = 0;
float Angle = 0.0f;
uint8_t start[3] = {0xAA,0x07,0xFF};  //����������ָ��

int main(void)
{
	Sys_Init();
	Hardware_Init();
	
	OLED_ShowString(3, 1, "Angle:");
	OLED_ShowString(4, 1, "Task:");
	
    while(1)
    {
		DelayTime();
		Angle = jy901_read();
		ADC_LR();
		
		OLED_ShowSignedNum(3, 7, Angle, 3);
		OLED_ShowNum(4, 6, Task, 2);
		Sensor_Test();
//		Motor_Test();
//		ADC_L_Test();
//		ADC_R_Test();
//      Task_Run();
		Task_One();
	}
}

